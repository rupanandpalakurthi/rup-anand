import React from 'react';
import { TrendingUp, TrendingDown, Star } from 'lucide-react';
import { Cryptocurrency } from '../types/crypto';
import { formatCurrency, formatNumber, formatPercentage, getPercentageColor } from '../utils/formatters';

interface CryptoCardProps {
  crypto: Cryptocurrency;
  isWatchlisted?: boolean;
  onToggleWatchlist?: (id: string) => void;
}

const CryptoCard: React.FC<CryptoCardProps> = ({ 
  crypto, 
  isWatchlisted = false, 
  onToggleWatchlist 
}) => {
  const {
    id,
    symbol,
    name,
    image,
    current_price,
    market_cap_rank,
    price_change_percentage_24h,
    market_cap,
    total_volume,
    sparkline_in_7d
  } = crypto;

  const priceChange = price_change_percentage_24h;
  const isPositive = priceChange >= 0;

  // Simple sparkline path generation
  const generateSparklinePath = (prices: number[]): string => {
    if (!prices || prices.length === 0) return '';
    
    const width = 100;
    const height = 30;
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const range = max - min || 1;
    
    const points = prices.map((price, index) => {
      const x = (index / (prices.length - 1)) * width;
      const y = height - ((price - min) / range) * height;
      return `${x},${y}`;
    }).join(' ');
    
    return `M ${points.replace(/,/g, ' L ').replace(/L /, 'M ')}`;
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-800/70 hover:border-gray-600 transition-all duration-300 group">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <img 
            src={image} 
            alt={name}
            className="w-10 h-10 rounded-full"
            onError={(e) => {
              e.currentTarget.src = `https://via.placeholder.com/40/3B82F6/FFFFFF?text=${symbol.charAt(0)}`;
            }}
          />
          <div>
            <h3 className="text-white font-semibold text-lg">{name}</h3>
            <p className="text-gray-400 text-sm uppercase">{symbol}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs font-medium">
            #{market_cap_rank}
          </span>
          {onToggleWatchlist && (
            <button
              onClick={() => onToggleWatchlist(id)}
              className={`p-1 rounded transition-colors duration-200 ${
                isWatchlisted 
                  ? 'text-yellow-400 hover:text-yellow-300' 
                  : 'text-gray-500 hover:text-yellow-400'
              }`}
            >
              <Star className={`w-4 h-4 ${isWatchlisted ? 'fill-current' : ''}`} />
            </button>
          )}
        </div>
      </div>

      {/* Price */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-2xl font-bold text-white">
            {formatCurrency(current_price)}
          </span>
          <div className={`flex items-center space-x-1 ${getPercentageColor(priceChange)}`}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span className="font-medium">
              {formatPercentage(priceChange)}
            </span>
          </div>
        </div>

        {/* Sparkline */}
        {sparkline_in_7d && sparkline_in_7d.price && (
          <div className="w-full h-8 mb-4">
            <svg viewBox="0 0 100 30" className="w-full h-full">
              <path
                d={generateSparklinePath(sparkline_in_7d.price)}
                fill="none"
                stroke={isPositive ? '#10B981' : '#EF4444'}
                strokeWidth="2"
                className="opacity-80"
              />
            </svg>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-gray-400 mb-1">Market Cap</p>
          <p className="text-white font-medium">{formatNumber(market_cap)}</p>
        </div>
        <div>
          <p className="text-gray-400 mb-1">Volume (24h)</p>
          <p className="text-white font-medium">{formatNumber(total_volume)}</p>
        </div>
      </div>
    </div>
  );
};

export default CryptoCard;