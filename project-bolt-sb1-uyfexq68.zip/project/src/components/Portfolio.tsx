import React from 'react';
import { PieChart, TrendingUp, TrendingDown, Wallet, Plus } from 'lucide-react';
import { mockPortfolio } from '../data/mockData';
import { formatCurrency, formatPercentage, getPercentageColor } from '../utils/formatters';

const Portfolio: React.FC = () => {
  const totalValue = mockPortfolio.reduce((sum, item) => sum + (item.amount * item.currentPrice), 0);
  const totalCost = mockPortfolio.reduce((sum, item) => sum + (item.amount * item.averagePrice), 0);
  const totalPnL = totalValue - totalCost;
  const totalPnLPercentage = ((totalValue - totalCost) / totalCost) * 100;

  return (
    <section className="py-16 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div className="mb-4 md:mb-0">
            <h2 className="text-3xl font-bold text-white mb-2">Your Portfolio</h2>
            <p className="text-gray-400">Track your cryptocurrency investments</p>
          </div>
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add Asset</span>
          </button>
        </div>

        {/* Portfolio Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Wallet className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-white font-semibold">Total Value</h3>
            </div>
            <p className="text-3xl font-bold text-white">{formatCurrency(totalValue)}</p>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="text-white font-semibold">Total P&L</h3>
            </div>
            <p className={`text-3xl font-bold ${getPercentageColor(totalPnL)}`}>
              {formatCurrency(totalPnL)}
            </p>
            <p className={`text-sm ${getPercentageColor(totalPnL)}`}>
              {formatPercentage(totalPnLPercentage)}
            </p>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <PieChart className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-white font-semibold">Best Performer</h3>
            </div>
            <p className="text-xl font-bold text-white">SOL</p>
            <p className="text-green-400 text-sm">+15.8%</p>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-amber-500/20 rounded-lg">
                <TrendingDown className="w-6 h-6 text-amber-400" />
              </div>
              <h3 className="text-white font-semibold">Assets</h3>
            </div>
            <p className="text-3xl font-bold text-white">{mockPortfolio.length}</p>
          </div>
        </div>

        {/* Portfolio Holdings */}
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl overflow-hidden">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-xl font-semibold text-white">Holdings</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-700/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Asset</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-300">Holdings</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-300">Avg. Price</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-300">Current Price</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-300">Value</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-300">P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {mockPortfolio.map((item) => {
                  const value = item.amount * item.currentPrice;
                  const cost = item.amount * item.averagePrice;
                  const pnl = value - cost;
                  const pnlPercentage = ((value - cost) / cost) * 100;

                  return (
                    <tr key={item.id} className="hover:bg-gray-700/30 transition-colors duration-200">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{item.symbol.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="text-white font-medium">{item.name}</p>
                            <p className="text-gray-400 text-sm">{item.symbol}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right text-white font-medium">
                        {item.amount.toFixed(4)}
                      </td>
                      <td className="px-6 py-4 text-right text-white">
                        {formatCurrency(item.averagePrice)}
                      </td>
                      <td className="px-6 py-4 text-right text-white">
                        {formatCurrency(item.currentPrice)}
                      </td>
                      <td className="px-6 py-4 text-right text-white font-medium">
                        {formatCurrency(value)}
                      </td>
                      <td className={`px-6 py-4 text-right font-medium ${getPercentageColor(pnl)}`}>
                        <div>
                          {formatCurrency(pnl)}
                        </div>
                        <div className="text-sm">
                          {formatPercentage(pnlPercentage)}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;