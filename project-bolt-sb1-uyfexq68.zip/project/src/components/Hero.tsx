import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react';
import { mockMarketStats } from '../data/mockData';
import { formatCurrency, formatNumber, formatPercentage, getPercentageColor } from '../utils/formatters';

const Hero: React.FC = () => {
  const { totalMarketCap, totalVolume, marketCapChange24h, bitcoinDominance } = mockMarketStats;

  const stats = [
    {
      label: 'Total Market Cap',
      value: formatCurrency(totalMarketCap),
      change: marketCapChange24h,
      icon: DollarSign,
    },
    {
      label: '24h Volume',
      value: formatCurrency(totalVolume),
      change: 1.2,
      icon: BarChart3,
    },
    {
      label: 'Bitcoin Dominance',
      value: `${bitcoinDominance.toFixed(1)}%`,
      change: 0.5,
      icon: TrendingUp,
    },
  ];

  return (
    <section className="bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20 pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Content */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Track Your Crypto
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent block">
              Portfolio
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Stay ahead of the market with real-time prices, comprehensive analytics, 
            and professional-grade portfolio management tools.
          </p>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 hover:bg-gray-800/70 transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-blue-500/20 rounded-lg">
                    <Icon className="w-6 h-6 text-blue-400" />
                  </div>
                  <div className={`flex items-center space-x-1 ${getPercentageColor(stat.change)}`}>
                    {stat.change >= 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span className="text-sm font-medium">
                      {formatPercentage(stat.change)}
                    </span>
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Hero;