import { Cryptocurrency, PortfolioItem, MarketStats } from '../types/crypto';

export const mockCryptoData: Cryptocurrency[] = [
  {
    id: 'bitcoin',
    symbol: 'btc',
    name: 'Bitcoin',
    image: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png',
    current_price: 43750.23,
    market_cap: 857234567890,
    market_cap_rank: 1,
    price_change_percentage_24h: 2.45,
    total_volume: 24567890123,
    high_24h: 44120.45,
    low_24h: 42890.12,
    circulating_supply: 19587234.5,
    total_supply: 19587234.5,
    max_supply: 21000000,
    sparkline_in_7d: {
      price: [42500, 43000, 42800, 43200, 43800, 43600, 43750]
    }
  },
  {
    id: 'ethereum',
    symbol: 'eth',
    name: 'Ethereum',
    image: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png',
    current_price: 2634.78,
    market_cap: 316789012345,
    market_cap_rank: 2,
    price_change_percentage_24h: -1.23,
    total_volume: 15678901234,
    high_24h: 2689.45,
    low_24h: 2598.12,
    circulating_supply: 120345678.9,
    total_supply: 120345678.9,
    max_supply: null,
    sparkline_in_7d: {
      price: [2650, 2620, 2680, 2640, 2610, 2645, 2635]
    }
  },
  {
    id: 'solana',
    symbol: 'sol',
    name: 'Solana',
    image: 'https://assets.coingecko.com/coins/images/4128/large/solana.png',
    current_price: 98.45,
    market_cap: 43567890123,
    market_cap_rank: 3,
    price_change_percentage_24h: 5.67,
    total_volume: 2345678901,
    high_24h: 101.23,
    low_24h: 92.87,
    circulating_supply: 442567890.1,
    total_supply: 580123456.7,
    max_supply: null,
    sparkline_in_7d: {
      price: [85, 88, 92, 96, 94, 97, 98]
    }
  },
  {
    id: 'binancecoin',
    symbol: 'bnb',
    name: 'BNB',
    image: 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png',
    current_price: 312.67,
    market_cap: 46789012345,
    market_cap_rank: 4,
    price_change_percentage_24h: 1.89,
    total_volume: 1234567890,
    high_24h: 318.45,
    low_24h: 305.23,
    circulating_supply: 149567890.1,
    total_supply: 149567890.1,
    max_supply: 200000000,
    sparkline_in_7d: {
      price: [305, 308, 312, 315, 310, 314, 313]
    }
  },
  {
    id: 'cardano',
    symbol: 'ada',
    name: 'Cardano',
    image: 'https://assets.coingecko.com/coins/images/975/large/cardano.png',
    current_price: 0.487,
    market_cap: 17234567890,
    market_cap_rank: 5,
    price_change_percentage_24h: -2.34,
    total_volume: 567890123,
    high_24h: 0.512,
    low_24h: 0.463,
    circulating_supply: 35123456789,
    total_supply: 45000000000,
    max_supply: 45000000000,
    sparkline_in_7d: {
      price: [0.52, 0.51, 0.49, 0.47, 0.48, 0.49, 0.487]
    }
  },
  {
    id: 'avalanche-2',
    symbol: 'avax',
    name: 'Avalanche',
    image: 'https://assets.coingecko.com/coins/images/12559/large/avalanche-avax-logo.png',
    current_price: 36.78,
    market_cap: 14567890123,
    market_cap_rank: 6,
    price_change_percentage_24h: 3.45,
    total_volume: 789012345,
    high_24h: 38.12,
    low_24h: 35.23,
    circulating_supply: 395123456.7,
    total_supply: 445123456.7,
    max_supply: 720000000,
    sparkline_in_7d: {
      price: [34, 35, 37, 36, 35, 37, 37]
    }
  }
];

export const mockPortfolio: PortfolioItem[] = [
  {
    id: 'bitcoin',
    symbol: 'BTC',
    name: 'Bitcoin',
    amount: 0.25,
    averagePrice: 41000,
    currentPrice: 43750.23
  },
  {
    id: 'ethereum',
    symbol: 'ETH',
    name: 'Ethereum',
    amount: 2.5,
    averagePrice: 2800,
    currentPrice: 2634.78
  },
  {
    id: 'solana',
    symbol: 'SOL',
    name: 'Solana',
    amount: 50,
    averagePrice: 85,
    currentPrice: 98.45
  }
];

export const mockMarketStats: MarketStats = {
  totalMarketCap: 1750234567890,
  totalVolume: 89012345678,
  marketCapChange24h: 2.15,
  bitcoinDominance: 49.2
};